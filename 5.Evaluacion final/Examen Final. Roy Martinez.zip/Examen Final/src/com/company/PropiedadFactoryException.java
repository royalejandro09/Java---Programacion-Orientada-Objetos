package com.company;

public class PropiedadFactoryException extends Exception{

    public PropiedadFactoryException(String message) {
        super(message);
    }
}
