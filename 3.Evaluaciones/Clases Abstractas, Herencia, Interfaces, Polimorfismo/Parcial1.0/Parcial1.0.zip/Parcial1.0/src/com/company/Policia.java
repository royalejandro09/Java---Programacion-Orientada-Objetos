package com.company;

public class Policia {

    //Atributos

    private String nombre;
    private String apellido;
    private Integer legajo;

    //Constructor


    public Policia(String nombre, String apellido, Integer legajo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
    }
}
