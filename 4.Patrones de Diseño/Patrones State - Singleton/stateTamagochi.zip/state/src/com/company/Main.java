package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Tamagochi tamagochi = new Tamagochi();

        System.out.println(tamagochi.getEstadoActual());

        tamagochi.darleMimos();
        tamagochi.darleMimos();
        tamagochi.darleMimos();
        tamagochi.darleMimos();
        tamagochi.darleMimos();
        tamagochi.darleMimos();
        tamagochi.darleMimos();

        System.out.println(tamagochi.getEstadoActual());




    }
}
