package com.company;

public interface Estado {

    public Estado comer();
    public Estado beber();
    public Estado mimar();
}
